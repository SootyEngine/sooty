# File Editor for Godot 4.0

# TODO:
- Rename files
- Rename folders
- Trash/Recycle system
- Highlighters for:
	- Markdown
	- JSON
	- YAML

# Features
- Ctrl+Click files for clickable "Table of Content" preview.

- .cfg
	- Colorize HTML hex strings: color="#ff0000" will be colorized red.
